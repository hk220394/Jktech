python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`

pip install fastapi uvicorn sqlalchemy psycopg2-binary openai pydantic

python main.py