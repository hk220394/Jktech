import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Document
import openai 

DATABASE_URL = "postgresql://username:password@localhost/dbname" 
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

app = FastAPI()

class DocumentIngest(BaseModel):
    title: str
    content: str

class Question(BaseModel):
    question: str

@app.post("/ingest")
async def ingest_document(doc: DocumentIngest):
    db = SessionLocal()
    try:
        embedding = generate_embedding(doc.content)  
        
        new_doc = Document(title=doc.title, content=doc.content, embedding=embedding)
        db.add(new_doc)
        db.commit()
        return {"message": "Document ingested successfully", "id": new_doc.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.post("/ask")
async def ask_question(q: Question):
    db = SessionLocal()
    try:
        relevant_docs = retrieve_relevant_documents(q.question) 
        
        answer = generate_answer(relevant_docs, q.question) 
        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

def generate_embedding(content):
    response = openai.Embedding.create(input=content, model="text-embedding-ada-002")
    return response['data'][0]['embedding']

def retrieve_relevant_documents(question):
    return []

def generate_answer(relevant_docs, question):
    return "This is a placeholder answer."  

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)