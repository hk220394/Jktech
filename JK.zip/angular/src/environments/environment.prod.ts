export const environment = {
    production: true,
    apiUrl: 'https://your-api-url.com' // Replace with your API URL for production.
};