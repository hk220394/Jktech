export const environment = {
    production: false,
    apiUrl: 'http://localhost/api' // Replace with your API URL for development.
};