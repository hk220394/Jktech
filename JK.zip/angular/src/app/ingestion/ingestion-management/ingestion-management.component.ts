import { Component } from '@angular/core';

@Component({
  selector: 'app-ingestion-management',
  templateUrl: './ingestion-management.component.html',
  styleUrls: ['./ingestion-management.component.scss'],
  standalone: false
})
export class IngestionManagementComponent {
  ingestionStatus: string = 'Not Started';
  errorMessage: string | null = null;

  constructor() { }

  triggerIngestion() {
    this.ingestionStatus = 'In Progress';
    this.errorMessage = null;

    setTimeout(() => {
      const success = Math.random() > 0.2;
      if (success) {
        this.ingestionStatus = 'Completed Successfully';
      } else {
        this.ingestionStatus = 'Failed';
        this.errorMessage = 'An error occurred during ingestion.';
      }
    }, 3000);
  }
}