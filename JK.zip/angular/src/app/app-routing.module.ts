import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { UserManagementComponent } from './admin/user-management/user-management.component';
import { DocumentUploadComponent } from './documents/document-upload/document-upload.component';
import { IngestionManagementComponent } from './ingestion/ingestion-management/ingestion-management.component';
import { QaInterfaceComponent } from './qa/qa-interface/qa-interface.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'user-management', component: UserManagementComponent },
  { path: 'document-upload', component: DocumentUploadComponent },
  { path: 'ingestion-management', component: IngestionManagementComponent },
  { path: 'qa', component: QaInterfaceComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }