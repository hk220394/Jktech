import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Document {
  id: number;
  name: string;
}

@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.scss']
})
export class DocumentUploadComponent {
  documents: Document[] = [];
  selectedFile: File | null = null;
  errorMessage: string | null = null;
  apiUrl = 'http://localhost:3000/documents/upload'; // Replace with your NestJS API URL

  constructor(private http: HttpClient) { }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      this.errorMessage = null; // Clear any previous error messages
    }
  }

  uploadDocument() {
    if (!this.selectedFile) {
      this.errorMessage = 'Please select a file to upload.';
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile, this.selectedFile.name);

    this.http.post(this.apiUrl, formData).subscribe(
      (response) => {
        const newDocument: Document = {
          id: this.documents.length + 1,
          name: this.selectedFile!.name
        };
        this.documents.push(newDocument);
        this.selectedFile = null;
        this.errorMessage = null;
      },
      (error) => {

        console.error('Upload error:', error);
        this.errorMessage = 'Failed to upload document. Please try again.';
      }
    );
  }
}