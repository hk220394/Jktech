import { Component } from '@angular/core';


interface User {
  id: number;
  username: string;
}

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss'],
  standalone: false
})
export class UserManagementComponent {
  users: User[] = [];
  newUserName: string = '';
  errorMessage: string | null = null;

  constructor() {
    this.users = [
      { id: 1, username: 'admin' },
      { id: 2, username: 'user1' },
      { id: 3, username: 'user2' }
    ];
  }

  addUser() {
    if (this.newUserName.trim() === '') {
      this.errorMessage = 'Username cannot be empty';
      return;
    }

    const newUser: User = {
      id: this.users.length + 1,
      username: this.newUserName.trim()
    };

    this.users.push(newUser);
    this.newUserName = '';
    this.errorMessage = null;
  }

  deleteUser(userId: number) {
    this.users = this.users.filter(user => user.id !== userId);
  }
}