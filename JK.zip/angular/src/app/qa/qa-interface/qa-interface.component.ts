import { Component } from '@angular/core';

@Component({
  selector: 'app-qa-interface',
  templateUrl: './qa-interface.component.html',
  styleUrls: ['./qa-interface.component.scss'],
  standalone: false
})
export class QaInterfaceComponent {
  question: string = '';
  answer: string | null = null;
  documentExcerpt: string = 'This is a sample document excerpt related to your question.';

  constructor() { }

  submitQuestion() {
    if (this.question.trim() === '') {
      this.answer = 'Please enter a question.';
      return;
    }

    this.answer = this.generateAnswer(this.question);
  }

  private generateAnswer(question: string): string {
    if (question.toLowerCase().includes('document')) {
      return `Here is some information about documents. Excerpt: "${this.documentExcerpt}"`;
    } else {
      return 'This is a simulated answer to your question.';
    }
  }
}