import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://your-api-url.com/auth';

  constructor(private http: HttpClient) { }

  login(username: string, password: string): Observable<any> {
    if (username === 'admin' && password === 'password') {
      return of({ success: true });
    } else {
      return of({ success: false });
    }
    /*
    return this.http.post(`${this.apiUrl}/login`, { username, password })
      .pipe(
        catchError(error => {
          console.error('Login error', error);
          return of({ success: false });
        })
      );
    */
  }

  signup(username: string, password: string): Observable<any> {
    if (username && password) {
      console.log('User signed up:', username);
      return of({ success: true });
    } else {
      return of({ success: false });
    }
    /*
    return this.http.post(`${this.apiUrl}/signup`, { username, password })
      .pipe(
        catchError(error => {
          console.error('Signup error', error);
          return of({ success: false });
        })
      );
    */
  }
}