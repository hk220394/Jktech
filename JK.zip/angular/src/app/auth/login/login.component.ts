import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  standalone: false
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string | null = null;

  constructor(private router: Router, private authService: AuthService) { }

  onLogin() {
    this.authService.login(this.username, this.password).subscribe((response: { success: any; }) => {
      if (response.success) {
        this.router.navigate(['/user-management']);
      } else {
        this.errorMessage = 'Invalid username or password';
      }
    });
  }
}