import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthCredentialsDto } from './dto/auth-credentials.dto';
import { JwtAuthGuard } from './jwt.guard';

@Controller('auth')
export class AuthController {
    constructor(private authService: AuthService) { }

    @Post('register')
    register(@Body() authCredentialsDto: AuthCredentialsDto) {
        return this.authService.register(authCredentialsDto);
    }

    @Post('login')
    login(@Body() authCredentialsDto: AuthCredentialsDto) {
        return this.authService.login(authCredentialsDto);
    }

    @UseGuards(JwtAuthGuard)
    @Post('logout')
    logout() {
        return this.authService.logout();
    }
}