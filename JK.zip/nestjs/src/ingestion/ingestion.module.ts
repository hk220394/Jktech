// src/ingestion/ingestion.module.ts

import { Module } from '@nestjs/common';
import { EmbeddingService } from './embedding.service';
import { IngestionService } from './ingestion.service';
import { DocumentModule } from '../document/document.module';
import { DocumentRepository } from '../document/document.repository';

@Module({
    imports: [DocumentModule],
    providers: [EmbeddingService, IngestionService, DocumentRepository],
    exports: [IngestionService],
})
export class IngestionModule { }
