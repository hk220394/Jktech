// src/ingestion/ingestion.controller.ts

import { Controller, Post, Body } from '@nestjs/common';
import { IngestionService } from './ingestion.service';
import { TriggerIngestionDto } from './dto/trigger-ingestion.dto';

@Controller('ingestion')
export class IngestionController {
    constructor(private readonly ingestionService: IngestionService) { }

    /**
     * Endpoint to trigger ingestion for a document.
     * POST /ingestion
     */
    @Post()
    async triggerIngestion(@Body() triggerIngestionDto: TriggerIngestionDto): Promise<void> {
        await this.ingestionService.triggerIngestion(triggerIngestionDto);
    }
}
