import { IsString, IsNotEmpty } from 'class-validator';

export class TriggerIngestionDto {
    @IsString()
    @IsNotEmpty()
    documentId: string;

    constructor(documentId?: string) {
        this.documentId = documentId || '';
    }
}