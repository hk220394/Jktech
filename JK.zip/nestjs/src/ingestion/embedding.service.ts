// src/ingestion/embedding.service.ts

import { Injectable, InternalServerErrorException } from '@nestjs/common';
import OpenAI from 'openai'; // Correct import for OpenAI

@Injectable()
export class EmbeddingService {
    private openai: OpenAI;

    constructor() {
        this.openai = new OpenAI({
            apiKey: 'your-api-key', // Replace with your OpenAI API key
        });
    }

    /**
     * Generates embeddings for the given content using OpenAI's API.
     * @param content - The text content to generate embeddings for.
     * @returns An array of numbers representing the embeddings.
     */
    async generateEmbeddings(content: string): Promise<number[]> {
        try {
            const response = await this.openai.embeddings.create({
                model: 'text-embedding-ada-002', // Example model
                input: content,
            });

            if (!response.data || response.data.length === 0) {
                throw new Error('No embeddings were returned by OpenAI');
            }

            return response.data[0].embedding; // Return the first embedding
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Embedding generation failed: ${error.message}`);
            } else {
                console.error('Unknown error during embedding generation', error);
            }
            throw new Error('Failed to generate embeddings');
        }
    }
}
