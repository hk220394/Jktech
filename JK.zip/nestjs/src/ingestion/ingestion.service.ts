// src/ingestion/ingestion.service.ts

import { Injectable, NotFoundException, InternalServerErrorException } from '@nestjs/common';
import { TriggerIngestionDto } from './dto/trigger-ingestion.dto';
import { EmbeddingService } from './embedding.service';
import { DocumentRepository } from '../document/document.repository';

@Injectable()
export class IngestionService {
    constructor(
        private readonly embeddingService: EmbeddingService,
        private readonly documentRepository: DocumentRepository
    ) { }

    async triggerIngestion(triggerIngestionDto: TriggerIngestionDto): Promise<void> {
        const { documentId } = triggerIngestionDto;

        try {
            const document = await this.documentRepository.findOne(documentId);
            if (!document) {
                throw new Error(`Document with ID ${documentId} not found`);
            }

            const embeddings = await this.embeddingService.generateEmbeddings(document.content);

            await this.documentRepository.storeEmbeddings(documentId, embeddings);

            console.log(`Ingestion completed for document ID: ${documentId}`);
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Ingestion failed: ${error.message}`);
            } else {
                console.error('Unknown error during ingestion', error);
            }
            throw new Error('Document ingestion failed');
        }
    }
}
