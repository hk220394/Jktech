import { Injectable } from '@nestjs/common';
import { AuthCredentialsDto } from '../auth/dto/auth-credentials.dto';
import { UserEntity } from './user.entity';
import { AssignRoleDto } from './dto/assign-role.dto';
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';


@Injectable()
export class UsersService {
    private userRepository;
    private users: UserEntity[] = [];
    constructor(private dataSource: DataSource) {
        this.userRepository = this.dataSource.getRepository(UserEntity);
    }

    async createUser(authCredentialsDto: AuthCredentialsDto): Promise<UserEntity> {
        const user = this.userRepository.create(authCredentialsDto);
        return await this.userRepository.save(user);
    }

    async validateUserPassword(authCredentialsDto: AuthCredentialsDto): Promise<UserEntity | null> {
        const { username, password } = authCredentialsDto;
        const user = await this.userRepository.findOne({ where: { username } });

        if (user) {
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (isPasswordValid) {
                return user;
            }
        }
        return null;
    }

    async findById(id: number): Promise<UserEntity | null> {
        return await this.userRepository.findOne({ where: { id } });
    }

    async assignRole(assignRoleDto: AssignRoleDto): Promise<UserEntity | null> {
        const userId = parseInt(assignRoleDto.userId);
        const user = this.users.find((u: UserEntity) => u.id === userId);

        if (user) {
            user.role = assignRoleDto.role;
            return user;
        }
        return null;
    }
}