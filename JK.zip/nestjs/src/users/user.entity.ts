import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

export enum UserRole {
    ADMIN = 'admin',
    EDITOR = 'editor',
    VIEWER = 'viewer',
}

@Entity('users')
export class UserEntity {
    @PrimaryGeneratedColumn()
    id: number | undefined;

    @Column({ unique: true })
    username: string;

    @Column()
    password: string;

    @Column({
        type: 'enum',
        enum: UserRole,
        default: UserRole.VIEWER,
    })
    role: UserRole;

    @Column({ nullable: true })
    email?: string;

    constructor(username?: string, password?: string, role?: UserRole) {
        this.username = username || '';
        this.password = password || '';
        this.role = role || UserRole.VIEWER;
    }
}