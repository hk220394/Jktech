import { IsString, IsNotEmpty } from 'class-validator';
import { UserRole } from '../user.entity';

export class AssignRoleDto {
    @IsString()
    @IsNotEmpty()
    userId: string;

    @IsString()
    @IsNotEmpty()
    role: UserRole;

    constructor(userId?: string, role?: UserRole) {
        this.userId = userId || '';
        this.role = role || UserRole.VIEWER;
    }
}