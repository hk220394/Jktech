import { Controller, Post, Body } from '@nestjs/common';
import { UsersService } from './users.service';
import { AssignRoleDto } from './dto/assign-role.dto';

@Controller('users')
export class UsersController {
    constructor(private readonly usersService: UsersService) { }

    @Post('assign-role')
    async assignRole(@Body() assignRoleDto: AssignRoleDto) {
        return await this.usersService.assignRole(assignRoleDto);
    }
}