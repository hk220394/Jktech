// src/documents/documents.module.ts

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DocumentEntity } from './document.entity';
import { DocumentRepository } from './document.repository';
import { DocumentService } from './document.service';
import { DocumentController } from './document.controller';

@Module({
    imports: [TypeOrmModule.forFeature([DocumentEntity])],
    providers: [DocumentRepository, DocumentService],
    controllers: [DocumentController],
    exports: [DocumentService],
})
export class DocumentModule { }
