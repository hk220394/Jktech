import { Injectable } from '@nestjs/common';
import { DocumentRepository } from './document.repository';
import { DocumentEntity } from './document.entity';
import { CreateDocumentDto } from './dto/create-document.dto';

@Injectable()
export class DocumentService {
    constructor(private readonly documentRepository: DocumentRepository) { }

    async create(createDocumentDto: CreateDocumentDto): Promise<void> {
        const document = new DocumentEntity();
        document.title = createDocumentDto.title;
        document.content = createDocumentDto.content;

        await this.documentRepository.save(document);
    }


    async getDocumentById(documentId: string): Promise<DocumentEntity> {
        const document = await this.documentRepository.findOne(documentId);
        if (!document) {
            throw new Error(`Document with ID ${documentId} not found`);
        }
        return document;
    }

    async createDocument(title: string, content: string): Promise<DocumentEntity> {
        const document = new DocumentEntity();
        document.title = title;
        document.content = content;
        document.createdAt = new Date(); // Ensure createdAt is a valid Date
        await this.documentRepository.save({
            title: document.title,
            content: document.content,
            createdAt: document.createdAt,
        });
        return document;
    }
}
