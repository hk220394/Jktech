// src/documents/document.repository.ts

import { Injectable, NotFoundException, InternalServerErrorException } from '@nestjs/common';
import { DataSource, FindOptionsWhere, Repository } from 'typeorm';
import { DocumentEntity } from './document.entity';

@Injectable()
export class DocumentRepository {
    private readonly repository: Repository<DocumentEntity>;

    constructor(private readonly dataSource: DataSource) {
        this.repository = this.dataSource.getRepository(DocumentEntity);
    }

    async retrieveDocuments(filters: Partial<DocumentEntity>): Promise<DocumentEntity[]> {
        try {
            const queryFilters: Partial<DocumentEntity> = { ...filters };
            if (queryFilters.embeddings === null) {
                delete queryFilters.embeddings;
            }

            return await this.repository.find({ where: queryFilters as FindOptionsWhere<DocumentEntity> }); // Use type assertion
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Error retrieving documents: ${error.message}`);
            } else {
                console.error('An unknown error occurred', error);
            }
            throw new InternalServerErrorException('Failed to retrieve documents');
        }
    }

    /**
     * Saves a new document to the database.
     * @param document - Object containing title, content, and createdAt.
     */
    async save(document: Partial<DocumentEntity>): Promise<void> {
        try {
            const completeDocument = {
                ...document,
                createdAt: document.createdAt ?? new Date()
            };
            await this.repository.save(completeDocument);
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Error saving document: ${error.message}`);
            } else {
                console.error('An unknown error occurred', error);
            }
            throw new Error('Failed to save document');
        }
    }

    /**
     * Finds a document by its ID.
     * @param documentId - The UUID of the document to find.
     * @returns The found DocumentEntity.
     * @throws NotFoundException if the document does not exist.
     */
    async findOne(documentId: string): Promise<DocumentEntity> {
        try {
            const idAsNumber = parseInt(documentId);
            const document = await this.repository.findOne({
                where: { id: idAsNumber },
            });

            if (!document) {
                throw new NotFoundException(`Document with ID ${documentId} not found.`);
            }

            return document;
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Error finding document: ${error.message}`);
            } else {
                console.error('Unknown error during document retrieval', error);
            }
            throw new InternalServerErrorException('Failed to retrieve the document.');
        }
    }

    /**
     * Stores embeddings for a specific document.
     * @param documentId - The UUID of the document.
     * @param embeddings - An array of numbers representing the embeddings.
     * @throws NotFoundException if the document does not exist.
     */
    async storeEmbeddings(documentId: string, embeddings: number[]): Promise<void> {
        try {
            const idAsNumber = parseInt(documentId)
            const result = await this.repository.update(
                { id: idAsNumber },
                { embeddings: embeddings } // Ensure correct type
            );

            if (result.affected === 0) {
                throw new Error(`Document with ID ${documentId} not found`);
            }
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Error storing embeddings: ${error.message}`);
            } else {
                console.error('Unknown error during embedding storage', error);
            }
            throw new Error('Failed to store embeddings');
        }
    }

    /**
     * Retrieves all documents matching certain filters.
     * @param filters - An object containing filter criteria.
     * @returns An array of DocumentEntity that match the filters.
     */
    async findAll(filters?: Partial<DocumentEntity>): Promise<DocumentEntity[]> {
        try {
            const documents = await this.repository.find({
                where: filters as FindOptionsWhere<DocumentEntity>, // Type assertion
            });
            return documents;
        } catch (error) {
            if (error instanceof Error) {
                console.error(`Error retrieving documents: ${error.message}`);
            } else {
                console.error('Unknown error during document retrieval', error);
            }
            throw new InternalServerErrorException('Failed to retrieve documents.');
        }
    }
}
