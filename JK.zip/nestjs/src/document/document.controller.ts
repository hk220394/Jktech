// src/documents/document.controller.ts

import { Controller, Post, Body, Get, Param } from '@nestjs/common';
import { DocumentService } from './document.service';
import { CreateDocumentDto } from './dto/create-document.dto';
import { DocumentEntity } from './document.entity';

@Controller('documents')
export class DocumentController {
    constructor(private readonly documentService: DocumentService) { }

    /**
     * Endpoint to create a new document.
     * POST /documents
     */
    @Post()
    async createDocument(@Body() createDocumentDto: CreateDocumentDto): Promise<void> {
        await this.documentService.create(createDocumentDto);
    }

    /**
     * Endpoint to retrieve a document by ID.
     * GET /documents/:id
     */
    @Get(':id')
    async getDocument(@Param('id') id: string): Promise<DocumentEntity> {
        return await this.documentService.getDocumentById(id);
    }
}
