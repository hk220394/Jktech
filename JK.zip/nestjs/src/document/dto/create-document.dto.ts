import { IsString, IsNotEmpty } from 'class-validator';

export class CreateDocumentDto {
    @IsString()
    @IsNotEmpty()
    title: string;

    @IsString()
    @IsNotEmpty()
    content: string;
    constructor(title?: string, content?: string) {
        this.title = title || '';
        this.content = content || '';
    }
}