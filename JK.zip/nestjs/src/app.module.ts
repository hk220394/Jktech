import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { DocumentModule } from './document/document.module';
import { IngestionModule } from './ingestion/ingestion.module';
import { DocumentEntity } from './document/document.entity';
import { DocumentRepository } from './document/document.repository';
import { DocumentService } from './document/document.service';
import { IngestionService } from './ingestion/ingestion.service';
import { EmbeddingService } from './ingestion/embedding.service';
@Module({
    imports: [
        TypeOrmModule.forRoot({
            type: 'postgres',
            host: 'localhost',
            port: 5432,
            username: 'your_username',
            password: 'your_password',
            database: 'your_database',
            entities: [__dirname + '/**/*.entity{ .ts,.js}'],
            synchronize: true,
        }),
        AuthModule,
        UsersModule,
        DocumentModule,
        IngestionModule,
    ],
    providers: [DocumentRepository, DocumentService, IngestionService, EmbeddingService],
    controllers: [], // Add your controllers here

})
export class AppModule { }
